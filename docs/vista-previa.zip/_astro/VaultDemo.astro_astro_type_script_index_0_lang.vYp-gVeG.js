import{a as j,$ as a,b as c,n as u,l as t,c as s,d as S}from"./demo-core.Bq6u5x2s.js";let i=[],h="general",l="balanced",p=!1;const r={ideas:{prompt:t("Ayúdame a organizar un nuevo proyecto.","Help me plan a new project."),answer:t(`Podemos darle forma en tres pasos:

1. Define a quién ayudará y qué problema resolverá.
2. Elige el recorrido más importante para una primera versión.
3. Convierte ese recorrido en una lista de pantallas y entregables.

Esta respuesta está preparada para mostrar la experiencia de conversación. En el producto completo, un modelo local responde a tus mensajes.`,`We can shape it in three steps:

1. Define who it will help and which problem it will solve.
2. Choose the most important workflow for a first version.
3. Turn that workflow into screens and deliverables.

This response is prepared to showcase the conversation experience. In the full product, a local model responds to your messages.`)},code:{prompt:t("Muéstrame una función sencilla de JavaScript.","Show me a simple JavaScript function."),answer:t(`Aquí tienes un ejemplo para calcular el total de una cesta:

function total(items) {
  return items.reduce((sum, item) => {
    return sum + item.price * item.quantity;
  }, 0);
}

Recorre cada producto y suma su precio por la cantidad. Este código es una respuesta de ejemplo, no se ejecuta en la demo.`,`Here is an example for calculating a basket total:

function total(items) {
  return items.reduce((sum, item) => {
    return sum + item.price * item.quantity;
  }, 0);
}

It goes through each product and adds its price times quantity. This code is a sample response and is not executed in the demo.`)},writing:{prompt:t("Ayúdame con la presentación de una marca.","Help me introduce a brand."),answer:t(`Una presentación clara puede comenzar con una promesa concreta:

“Creamos herramientas digitales que simplifican el trabajo de cada día.”

Después puedes explicar para quién trabajas, qué necesidad resuelves y cómo acompañas al cliente.

Este borrador es un ejemplo preparado para explorar el modo de escritura.`,`A clear introduction can start with a concrete promise:

“We build digital tools that make everyday work simpler.”

Then explain who you work for, which need you solve, and how you support the customer.

This draft is a prepared example for exploring writing mode.`)}};let v=[{title:t("Ideas para un nuevo proyecto","Ideas for a new project"),messages:[{role:"user",text:r.ideas.prompt},{role:"assistant",text:r.ideas.answer}]},{title:t("Una función, paso a paso","A function, step by step"),messages:[{role:"user",text:r.code.prompt},{role:"assistant",text:r.code.answer}]}];const b=j();function g(){const e=a("#chat-messages");c(".message",e).forEach(n=>n.remove()),a("#vault-welcome").hidden=i.length>0,i.forEach(n=>{const o=s("article","","message "+n.role),d=s("span",n.role==="assistant"?"✧":t("Tú","You"),"message-avatar"),m=s("div");m.append(s("strong",n.role==="assistant"?"Akashic Vault":t("Tú","You")),s("p",n.text)),o.append(d,m),e.append(o)})}function f(e){h=e,c("[data-mode]").forEach(n=>n.setAttribute("aria-pressed",String(n.dataset.mode===h)))}function L(e){const n=e.toLowerCase();return h==="code"||/javascript|código|code|función|function/.test(n)?r.code.answer:h==="writing"||/texto|marca|escrib|writ|brand/.test(n)?r.writing.answer:r.ideas.answer}function y(e){e.trim()&&(i.push({role:"user",text:e.trim().slice(0,1200)},{role:"assistant",text:L(e)}),g(),a("#chat-input").value="",a("#chat-messages").lastElementChild?.scrollIntoView({block:"nearest",behavior:document.documentElement.hasAttribute("data-motion")||matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth"}))}a("#chat-form button[type=submit]").disabled=!1;a("#chat-form").addEventListener("submit",e=>{e.preventDefault(),y(a("#chat-input").value)});c("[data-prompt]").forEach(e=>e.addEventListener("click",()=>{const n=e.dataset.prompt;f(n==="code"?"code":n==="writing"?"writing":"general"),y(r[n].prompt)}));c("[data-mode]").forEach(e=>e.addEventListener("click",()=>f(e.dataset.mode)));a("#new-chat").addEventListener("click",()=>{i=[],g(),b("chat"),a("#chat-input").focus(),u(t("Nueva conversación de prueba.","New sample conversation."))});function E(e){i=v[e].messages.map(n=>({...n})),g(),b("chat")}c("[data-history]").forEach(e=>e.addEventListener("click",()=>E(e.dataset.history==="ideas"?0:1)));function x(){const e=a("#vault-records");e.replaceChildren(),v.forEach((n,o)=>{const d=s("article","","surface vault-record"),m=s("span","▤","soft-icon"),w=s("div");w.append(s("h2",n.title),s("p",n.messages.length+t(" mensajes de ejemplo · Solo en memoria"," sample messages · Memory only"),"muted")),d.append(m,w,S(t("Abrir","Open"),()=>E(o))),e.append(d)})}a("#save-chat").addEventListener("click",()=>{if(!i.length)return u(t("Prueba una conversación antes de guardar el ejemplo.","Try a conversation before saving the example."));v.push({title:i[0].text.slice(0,65),messages:i.map(e=>({...e}))}),x(),u(t("Ejemplo añadido a la bóveda de esta pestaña. No se ha guardado en el dispositivo.","Example added to this tab’s vault. It has not been saved to your device."))});a("#toggle-vault").addEventListener("click",()=>{p=!p,a("#vault-records").hidden=p,a("#vault-locked").hidden=!p,a("#toggle-vault").textContent=p?t("Desbloquear muestra","Unlock showcase"):t("Bloquear muestra","Lock showcase")});c("[data-model]").forEach(e=>e.addEventListener("click",()=>{l=e.dataset.model,c("[data-model]").forEach(o=>{const d=o.dataset.model===l;o.setAttribute("aria-pressed",String(d)),o.textContent=d?t("Seleccionado","Selected"):t("Seleccionar perfil","Select profile")});const n={balanced:t("Equilibrado","Balanced"),coder:t("Programación","Coding"),creative:t("Creativo","Creative")}[l];a("#vault-engine").textContent=t("Perfil de ejemplo · ","Sample profile · ")+n,f(l==="coder"?"code":l==="creative"?"writing":"general"),u(t("Perfil de muestra seleccionado. No se ha descargado ningún modelo.","Sample profile selected. No model has been downloaded."))}));function k(e){document.body.classList.toggle("vault-light",e==="light"),a("#vault-appearance").value=e,a("#vault-theme").setAttribute("aria-pressed",String(e==="light"))}a("#vault-theme").addEventListener("click",()=>k(document.body.classList.contains("vault-light")?"dark":"light"));a("#vault-appearance").addEventListener("change",e=>k(e.target.value));a("#studio-form button[type=submit]").disabled=!1;a("#studio-form").addEventListener("submit",e=>{e.preventDefault(),a("#studio-placeholder").hidden=!0,a("#studio-result").hidden=!1;const n=a("#studio-type").value,o=a("#studio-style").value;a(".generated-landscape").dataset.style=o,a(".generated-landscape").classList.toggle("moving-preview",n==="video"),a("#studio-caption").textContent=(n==="video"?t("Vista de video simulada para: ","Simulated video preview for: "):t("Imagen de muestra para: ","Sample image for: "))+a("#studio-prompt").value,u(t("Vista de ejemplo preparada. No se ha ejecutado ningún motor.","Sample preview prepared. No engine was executed."))});x();
